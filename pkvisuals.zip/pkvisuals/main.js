/* PK Visuals — Main JS */

/* --- NAV SCROLL BEHAVIOUR --- */
const nav = document.getElementById('nav');
const navToggle = document.getElementById('navToggle');
const navLinks = document.getElementById('navLinks');

window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > 40);
}, { passive: true });

navToggle?.addEventListener('click', () => {
  navToggle.classList.toggle('open');
  navLinks.classList.toggle('open');
  document.body.style.overflow = navLinks.classList.contains('open') ? 'hidden' : '';
});

navLinks?.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navToggle.classList.remove('open');
    navLinks.classList.remove('open');
    document.body.style.overflow = '';
  });
});

/* --- REVEAL ON SCROLL --- */
const revealEls = document.querySelectorAll(
  '.section-header, .service-item, .package-card, .stat-item, .reel-card, .work-item, .case-card, .service-detail-media, .service-detail-content, .booking-form-wrap, .booking-info-card'
);

revealEls.forEach((el, i) => {
  el.classList.add('reveal');
  if (i % 3 === 1) el.classList.add('reveal-delay-1');
  if (i % 3 === 2) el.classList.add('reveal-delay-2');
});

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('visible');
      revealObserver.unobserve(e.target);
    }
  });
}, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

revealEls.forEach(el => revealObserver.observe(el));

/* --- STATS COUNTER --- */
function animateCounter(el, target, duration = 1800) {
  const start = performance.now();
  const update = (now) => {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 4);
    el.textContent = Math.round(ease * target);
    if (progress < 1) requestAnimationFrame(update);
  };
  requestAnimationFrame(update);
}

const statNums = document.querySelectorAll('.stat-num[data-target]');
if (statNums.length) {
  const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const target = parseInt(e.target.dataset.target, 10);
        animateCounter(e.target, target);
        statsObserver.unobserve(e.target);
      }
    });
  }, { threshold: 0.5 });
  statNums.forEach(el => statsObserver.observe(el));
}

/* --- WORK FILTER --- */
const filterBtns = document.querySelectorAll('.filter-btn');
const workItems = document.querySelectorAll('.work-item');

filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const filter = btn.dataset.filter;
    workItems.forEach(item => {
      const cats = item.dataset.category || '';
      const show = filter === 'all' || cats.includes(filter);
      item.style.display = show ? '' : 'none';
    });
  });
});

/* --- HERO VIDEO PLAY (muted autoplay fallback) --- */
const heroVideo = document.getElementById('heroVideo');
if (heroVideo) {
  heroVideo.play().catch(() => {
    /* autoplay blocked — fallback gradient is already visible */
  });
}

/* --- BOOKING FORM --- */
const bookingForm = document.getElementById('bookingForm');
const formSuccess = document.getElementById('formSuccess');

bookingForm?.addEventListener('submit', (e) => {
  e.preventDefault();

  const required = bookingForm.querySelectorAll('[required]');
  let valid = true;

  required.forEach(field => {
    if (field.type === 'checkbox') {
      if (!field.checked) { valid = false; field.closest('.checkbox-item').style.color = '#e05'; }
    } else {
      if (!field.value.trim()) { valid = false; field.style.borderBottomColor = '#e05'; }
      else field.style.borderBottomColor = '';
    }
  });

  if (!valid) return;

  /* Simulate submission — replace with your actual form endpoint */
  const btn = bookingForm.querySelector('[type="submit"]');
  btn.textContent = 'Sending…';
  btn.disabled = true;

  setTimeout(() => {
    bookingForm.style.display = 'none';
    formSuccess.style.display = 'block';
  }, 1200);
});

/* --- SMOOTH HASH SCROLL --- */
document.querySelectorAll('a[href*="#"]').forEach(anchor => {
  anchor.addEventListener('click', (e) => {
    const url = new URL(anchor.href, location.href);
    if (url.pathname === location.pathname && url.hash) {
      const target = document.querySelector(url.hash);
      if (target) {
        e.preventDefault();
        const offset = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--nav-h'), 10) || 72;
        const top = target.getBoundingClientRect().top + window.scrollY - offset - 24;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    }
  });
});
